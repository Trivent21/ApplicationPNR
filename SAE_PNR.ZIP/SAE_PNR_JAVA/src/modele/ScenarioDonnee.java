package modele;
import java.util.Date;
import modele.donnee.*;
import java.util.ArrayList;
import java.sql.*;
/**
 * @author mateo FLEJOU
 */
public class ScenarioDonnee {
    
    public static void main(String[] args) {

        Lieu place = new Lieu(2.487,7.239);

        Observateur mathis = new Observateur(378,"mathis","Badass");
        // Test Observateur
        // Observateur antho = new Observateur(-47,"Antho","grary");
       
        ArrayList<Observateur> listObs = new ArrayList<Observateur>(); 

        for (Observateur cl : listObs) {
            listObs.add(cl);
        }
       
        Date date1 = new Date();

        long timeInMilliSeconds = date1.getTime();
        java.sql.Date date = new java.sql.Date(timeInMilliSeconds);
        
        long now = System.currentTimeMillis();
        Time heure = new Time(now);
        int [] tableau = {2,3,4,6};
        int [] tableauErreur = {1};
       
        Observation maObs = new ObsBatracien(20,date,heure,place,listObs,tableau,EspeceBatracien.CALAMITE);
        // Test de Observation : 
        // Observation maObsTest = new ObsBatracien(-10,date,heure,place,listObs,tableau,EspeceBatracien.CALAMITE);
        // Observation maObsTest = new ObsBatracien(10,date,heure,null,listObs,tableau,EspeceBatracien.CALAMITE);
        // Observation maObsTest = new ObsBatracien(10,date,null,null,listObs,tableau,EspeceBatracien.CALAMITE);

        // Test Batracien 
        // Observation maObsTest = new ObsBatracien(10,date,heure,place,listObs,tableau,null);
        // Observation maObsTest = new ObsBatracien(10,date,heure,place,listObs,tableauErreur,EspeceBatracien.CALAMITE);
    
        Observation maObs1 = new ObsGCI(100,date,heure,place,listObs,ContenuNid.NID_SEUL,0);
        // Test GCI 
        // Observation maObsTest = new ObsGCI(100,date,heure,place,listObs,ContenuNid.NID_SEUL,-172);
        // Observation maObsTest = new ObsGCI(100,date,heure,place,listObs,null,1);

        Observation maObs2 = new ObsHippocampe(48, date, heure, place, listObs, 45.87, Peche.CASIER_CREVETTES, EspeceHippocampe.HIPPOCAMPUS_HIPPOCAMPUS, Sexe.MALE);
        // Test Hippocampe
        // Observation maObsTest = new ObsHippocampe(48, date, heure, place, listObs, 45.87, null, EspeceHippocampe.HIPPOCAMPUS_HIPPOCAMPUS, Sexe.MALE);
        // Observation maObsTest = new ObsHippocampe(48, date, heure, place, listObs, -45, Peche.CASIER_CREVETTES, EspeceHippocampe.HIPPOCAMPUS_HIPPOCAMPUS, Sexe.MALE);

        Observation maObs3 = new ObsChouette(39, date, heure, place, listObs,TypeObservation.SONORE );
        // Test ObsChouette 
        // Observation maObsTest = new ObsChouette(39, date, heure, place, listObs,null);

        Observation maobs4 = new ObsLoutre(30, date, heure, place, listObs, IndiceLoutre.POSITIF);
        // Test ObsLoutre
        // Observation maObsTest = new ObsLoutre(30, date, heure, place, listObs,null);
        
        //Méthode Observation TEST 
        // ajouterObservateur
        System.out.println("OBSERVATEUR TESTE METHODE");
        Observateur jule = new Observateur(38,"Jule","Alll");
        maobs4.ajouteObservateur(jule);
        maobs4.ajouteObservateur(null); //Message d'Erreur
        // retireObservateur 
        maobs4.retireObservateur(38);
        maobs4.retireObservateur(12226382);

        //Méthode NidGCI 

        java.sql.Date datePlusTard = new java.sql.Date(timeInMilliSeconds-890000);
        Observation maObs12 = new ObsGCI(376,datePlusTard,heure,place,listObs,ContenuNid.NID_SEUL,6);
        NidGCI NidPlage1 = new NidGCI(20, "Une plage");
        NidPlage1.ajouteUneObs((ObsGCI) maObs12);
        NidPlage1.ajouteUneObs((ObsGCI) maObs1);
        System.out.println("\nTESTE NIDGCI METHODE \n\nTest Ajout Nombre de obs actuelle 2 = " + NidPlage1.nbObs());

        java.sql.Date datePremiere = NidPlage1.dateDebutObs();
        java.sql.Date dateDeuxeime = NidPlage1.dateFinObs();
        
        Boolean res = NidPlage1.retireObs(376);
        System.out.println("\nTest True Retire obs nid : " + res + " Nombre de obs : " + NidPlage1.nbObs()); //Résultat True
        res = NidPlage1.retireObs(40);
        System.out.println("\nTest False Retire obs nid : " + res + " Nombre de obs : " + NidPlage1.nbObs()); //Résultat False
        NidPlage1.videObs();
        System.out.println("\nTest vide obs : " + NidPlage1.nbObs());

        datePremiere = NidPlage1.dateDebutObs(); //Message d'erreur
        dateDeuxeime = NidPlage1.dateFinObs(); //Message d'erreur
        //Test Chouette 
        
        Observation maObs13 = new ObsChouette(40, datePlusTard, heure, place, listObs, TypeObservation.SONORE);
        Chouette laChouetteBleu = new Chouette("Chouette Bleu", Sexe.INCONNU, EspeceChouette.EFFRAIE);
        laChouetteBleu.ajouteUneObs((ObsChouette) maObs3);
        laChouetteBleu.ajouteUneObs((ObsChouette) maObs13);
        System.out.println("\nTESTE CHOUETTE METHODE \n\nTest Ajout Nombre de obs actuelle 2 = " + laChouetteBleu.nbObs());

        res = laChouetteBleu.retireObs(41); //Résultat False
        System.out.println("\nTest False Retire obs Chouette : " + res + " Nombre de obs : " + laChouetteBleu.nbObs()); 

        res = laChouetteBleu.retireObs(40); // Résultat true
        System.out.println("\nTest True Retire obs Chouette : " + res + " Nombre de obs : " + laChouetteBleu.nbObs()); 

        laChouetteBleu.videObs();
        System.out.println("\nTest vide obs : " + NidPlage1.nbObs());

    }   
}
