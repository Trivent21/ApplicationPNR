package modele.donnee;
/**
 * @author Mateo Flejou
 * class Lieu
 */
public class Lieu {
	/**Coordonne d'un lieu sur une carte par exemple*/
	/**
	 * Private visibillity
	 */
	private double yCoord;
	/**
	 * Private visibillity
	 */
	private double xCoord;

	/**
	 * Constructeur de Lieu
	 * @param x - Coordonne X
	 * @param y - Coordonne Y
	 */
	public Lieu(double x, double y) {
		this.yCoord = y;
		this.xCoord = x;
	}
	/**
	 * Donne le Y de l'objet Lieu
	 * 
	 * @return Y - La coordonne Y 
	 */
	public double getYCoord() {
		return this.yCoord;
	}

	/**
	 * Change de Y de l'objet Lieu 
	 * 
	 * @param yCoord Y - Nouvelle coordonne Y 
	 */
	public void setYCoord(double yCoord) {
		this.yCoord = yCoord;
	}
	/**
	 * Donne le X de l'objet Lieu
	 * 
	 * @return xCoord - La coordonne X 
	 */
	public double getXCoord() {
		return this.xCoord;
	}

	/**
	 * Change de X de l'objet Lieu 
	 * 
	 * @param xCoord X - Nouvelle coordonne X 
	 */
	public void setXCoord(double xCoord) {
		this.xCoord = xCoord;
	}

}