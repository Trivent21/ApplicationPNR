package modele.donnee;

public enum Peche {
	CASIER_CREVETTES,
	CASIER_MORGATES,
	PETIT_FILET,
	VERVEUX_ANGUILLES,
	NON_RENSEIGNE
}