package modele.donnee;

public enum EspeceChouette {
	EFFRAIE,
	CHEVECHE,
	HULOTTE
}