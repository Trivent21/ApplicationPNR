package modele.donnee;

import java.util.ArrayList;
/**
 * @author Clement MONFORT
 * Class ObsLoutre
 */
public class ObsLoutre extends Observation {
   /** Visibilité privé */
    private IndiceLoutre indice;

    /**
     * Constructeur de le l'objet ObsLoutre:
     * 
     * @param id (int), l'identifiant de l'observation d'une Loutre.
     * @param date (sql.Date), date de l'observation.
     * @param heure (sql.Time), l'heure de l'observation.
     * @param lieu (enum), lieu de l'observation.
     * @param observateurs ArrayList(Observateur), les personnes qui ont fait l'observation.
     * @param indice (enum), le type d'observation.
     */
    public ObsLoutre(int id, java.sql.Date date, java.sql.Time heure, Lieu lieu,ArrayList<Observateur> observateurs, IndiceLoutre indice) {
        super(id, date, heure, lieu, observateurs);
        setIndice(indice);
    }

    /**
     * Rentourne l'identifiant de l'objet ObsLoutre.
     * 
     * @return (int), l'identifiant de l'ObsLoutre.
     */
    public IndiceLoutre getIndice() {
        return (this.indice);
    }

    /**
     * Change l'attribut indice de l'objet ObsLoutre.
     * 
     * @param indice (enum), le nouvelle indice de l'ObsLoutre.
     */
    public void setIndice(IndiceLoutre indice) {
        this.indice = indice;
    }

    /**
     * Donne l'espece de la sous-classe
     * @return EspeceObservee.LOUTRE
     */
    public EspeceObservee especeObs() {
        return EspeceObservee.LOUTRE;
    }
}