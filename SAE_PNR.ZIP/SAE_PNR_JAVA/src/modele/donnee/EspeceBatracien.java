package modele.donnee;

public enum EspeceBatracien {
	CALAMITE,
	PELODYTE;

}