package modele.donnee;

public enum Sexe {
	MALE,
	FEMELLE,
	INCONNU
}