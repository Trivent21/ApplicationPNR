package controleur;
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import javax.swing.event.TableModelEvent;
import javax.sql.RowSetListener;

public class PageAC extends JFrame {
   private JButton logiButton;
   private JTextField mP;

    public PageAC() {

    }
    public static void main(String args[]) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                PageAC frame = new PageAC();
                frame.pack();
                frame.setVisible(true);
            }
        });
    }
}
 