
import javax.swing.*;
import java.awt.*;

public class SelectionEspece extends JPanel{
    JPanel panel;
    JPanel login;
    JPanel bouton;
    JLabel idT;
    JLabel mdpT;
    JTextField id;
    JTextField mdp;
    JButton connexion;
    public SelectionEspece(){
        initComponents();
    }

    public void initComponents(){
        panel = new JPanel();

            panel.setBounds(61, 11, 81, 140);
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            this.add(panel);
            

            

        this.setLayout(new BorderLayout());
    }
}