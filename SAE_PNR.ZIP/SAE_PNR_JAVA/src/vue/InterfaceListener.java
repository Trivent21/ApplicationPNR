
import java.awt.event.*;
public class InterfaceListener extends KeyAdapter implements ActionListener{
    private Interface main;

    public InterfaceListener(Interface view){
        this.main = view;
    }

    public void actionPerformed(ActionEvent e){
        
    }

    public void keyPressed(KeyEvent e){
    }
}