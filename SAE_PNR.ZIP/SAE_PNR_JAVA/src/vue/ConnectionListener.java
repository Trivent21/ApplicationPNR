
import java.awt.event.*;
public class ConnectionListener implements ActionListener{
    Connection view;
    public ConnectionListener(Connection view){
        this.view = view;   
    }

    public void actionPerformed(ActionEvent e){
        this.view.next();
       
    }
}