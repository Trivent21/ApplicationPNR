
import javax.swing.*;
import java.awt.*;

public class Connection extends JPanel{
    Interface view;
    JPanel panel;
    JPanel login;
    JPanel bouton;
    JLabel idT;
    JLabel mdpT;
    JTextField id;
    JTextField mdp;
    JButton connexion;
    ConnectionListener listener;
    public Connection(Interface view){
        this.view = view;
        panel = new JPanel();
        this.login = new JPanel();
        //this.login.setLayout(new GridLayout(2,2));
        this.bouton = new JPanel();
        this.idT = new JLabel("Identifiant:");
        this.mdpT = new JLabel("Mot de passe:");
        this.id = new JTextField();
        this.id.setPreferredSize(new Dimension(80,15));
        this.mdp = new JTextField();
        this.mdp.setPreferredSize(new Dimension(80,15));
        this.connexion = new JButton("Connexion");
        ConnectionListener listener = new ConnectionListener(this);
        this.connexion.addActionListener(listener);

        this.setLayout(new BorderLayout());
        this.add(login, BorderLayout.CENTER);
        this.add(bouton, BorderLayout.SOUTH);
        this.login.add(idT);
        this.login.add(id);
        this.login.add(mdpT);
        this.login.add(mdp);
        //this.panel.add(login);
        this.bouton.add(new JLabel(""));
        this.bouton.add(connexion);
        this.connexion.addActionListener(listener);
    }

    public void next(){
        this.view.change("Espece");
    }
}