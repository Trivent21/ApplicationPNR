
import javax.swing.*;
import java.awt.*;
public class Interface extends JFrame{
    private InterfaceListener listener;
    private CardLayout card;
    private Connection connection;
    private SelectionEspece espece;
    private Container container;
    public Interface(){
        initComponents();
    }

    private void initComponents(){
        setTitle("Gestion des donnee");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        connection = new Connection(this);
        espece = new SelectionEspece();
        listener = new InterfaceListener(this);
        container = new Container();
        card = new CardLayout();
        container = getContentPane();
        container.setLayout(card);
        container.add("Connection",connection);
        container.add("Espece",espece);
        card.first(container);
        this.pack();
       
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Interface().setVisible(true);
            }
        });
    }

    public void change(String name){
        card.show(container,name);
    }
}